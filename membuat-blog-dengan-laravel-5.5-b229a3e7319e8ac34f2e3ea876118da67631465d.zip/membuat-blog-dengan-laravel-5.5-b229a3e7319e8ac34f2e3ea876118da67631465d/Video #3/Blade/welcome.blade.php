@extends('includes.head')
@section('title', 'Welcome')

@section('content')


 <div class="header_wrap">
  <div class="info">
     <div class="container">
         <div class="row">
            <div class="col-md-7">
                 <div class="header_info">
                    <div class="descrip">
                        <a href="#">
                        <h1 style="color:#ece705; font-weight: bold;     margin-top: 0;">WELCOME</h1>
                          </a> 
                         <p>
                           Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis, omnis doloremque non cum id reprehenderit, quisquam totam aspernatur tempora minima unde aliquid ea culpa sunt.
                           </p><br>
                           <div>
                           <p>
                            <a href="#" class="btn btn-danger" >Singup</a>
                             <a href="#" class="btn btn-danger" >Login</a>
                            </p>

                            </div>
                         </div>
                    </div>
                </div>
            </div>
        </div>
  </div>
</div>
 
        <section class="wp-separator">
            <article class="section">
                <div class="container">
                    <div class="row text-center">
                        <p class="h1">ACTIVITIES & EVENTS</p>
                        <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum nam numquam voluptates cumque </p>
                    </div>
                </div>
            </article>
        </section>

<div class="container-fluid">
        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-md-9">
                <div class="well well-sm wl">
                    
                    <div class="btn-group">
                        <a href="#" id="list" class="btn btn-default btn-sm"><span class="fa fa-th-list">
                        </span> List</a> <a href="#" id="grid" class="btn btn-default btn-sm"><span
                            class="fa fa-th"></span> Grid</a>
                    </div>
                </div>
  
      <div id="grid_post" class="row list-group">
 
         <div class="item  col-xs-4 col-lg-4">
            <div class="thumbnail as">
               <img class="group list-group-image" src="../images/post1.jpeg" alt="" />
                <div class="caption">
                    <div class="c_hr">
                    <h4 class="group inner list-group-item-heading"><a href="#}">Post Title</a></h4>
                         <small> 10 Oktober 2017, 8:25pm</small> | by <a href="#">Admin</a>

                     </div>
                    <p class="group inner list-group-item-text">Post Content</p>
                    <div class="row"></div>
                </div>
                
            </div>
        </div>
     
     <div class="item  col-xs-4 col-lg-4">
            <div class="thumbnail as">
               <img class="group list-group-image" src="../images/post1.jpeg" alt="" />
                <div class="caption">
                    <div class="c_hr">
                    <h4 class="group inner list-group-item-heading"><a href="#}">Post Title</a></h4>
                         <small> 10 Oktober 2017, 8:25pm</small> | by <a href="#">Admin</a>

                     </div>
                    <p class="group inner list-group-item-text">Post Content</p>
                    <div class="row"></div>
                </div>
                
            </div>
        </div>

        <div class="item  col-xs-4 col-lg-4">
            <div class="thumbnail as">
               <img class="group list-group-image" src="../images/post1.jpeg" alt="" />
                <div class="caption">
                    <div class="c_hr">
                    <h4 class="group inner list-group-item-heading"><a href="#}">Post Title</a></h4>
                         <small> 10 Oktober 2017, 8:25pm</small> | by <a href="#">Admin</a>

                     </div>
                    <p class="group inner list-group-item-text">Post Content</p>
                    <div class="row"></div>
                </div>
                
            </div>
        </div>

        <div class="item  col-xs-4 col-lg-4">
            <div class="thumbnail as">
               <img class="group list-group-image" src="../images/post1.jpeg" alt="" />
                <div class="caption">
                    <div class="c_hr">
                    <h4 class="group inner list-group-item-heading"><a href="#}">Post Title</a></h4>
                         <small> 10 Oktober 2017, 8:25pm</small> | by <a href="#">Admin</a>

                     </div>
                    <p class="group inner list-group-item-text">Post Content</p>
                    <div class="row"></div>
                </div>
                
            </div>
        </div>

        <div class="item  col-xs-4 col-lg-4">
            <div class="thumbnail as">
               <img class="group list-group-image" src="../images/post1.jpeg" alt="" />
                <div class="caption">
                    <div class="c_hr">
                    <h4 class="group inner list-group-item-heading"><a href="#}">Post Title</a></h4>
                         <small> 10 Oktober 2017, 8:25pm</small> | by <a href="#">Admin</a>

                     </div>
                    <p class="group inner list-group-item-text">Post Content</p>
                    <div class="row"></div>
                </div>
                
            </div>
        </div>

        <div class="item  col-xs-4 col-lg-4">
            <div class="thumbnail as">
               <img class="group list-group-image" src="../images/post1.jpeg" alt="" />
                <div class="caption">
                    <div class="c_hr">
                    <h4 class="group inner list-group-item-heading"><a href="#}">Post Title</a></h4>
                         <small> 10 Oktober 2017, 8:25pm</small> | by <a href="#">Admin</a>

                     </div>
                    <p class="group inner list-group-item-text">Post Content</p>
                    <div class="row"></div>
                </div>
                
            </div>
        </div>
  </div><!-- end grid -->
</div>

    <div class="col-md-3">
           <div class="list-group" style="box-shadow: 0 0px 1px 0px rgba(0, 0, 0, 0.26);">
          <a href="#" class="list-group-item active">
          Total 10 Tags <small class="pull-right">Lihat Semua  <i class="fa fa-share "></i> </small></a>
          <a href="#" class="list-group-item">Laravel<span class="badge badge-primary">10 Posts</span></a>
          <a href="#" class="list-group-item">PHP<span class="badge badge-primary">10 Posts</span></a>
         
        </div>

         <div class="list-group" style="box-shadow: 0 0px 1px 0px rgba(0, 0, 0, 0.26);">
         
         <a href="#" class="list-group-item active">Total 2 Kategori <small class="pull-right">Lihat Semua  <i class="fa fa-share "></i> </small> </a>
         <a href="#" class="list-group-item">Bahasa Pemograman Web<span class="badge badge-primary">6 Posts</span></a>
         <a href="#" class="list-group-item">Desain Web<span class="badge badge-primary">6 Posts</span></a>

        </div>
        <div class="ads-img" style="border: 11px solid #eee;">
          <img src="../images/img-sid.jpeg" style="width: 100%; height: auto;">
         </div>
         </div>
    </div><!-- end row -->
</div>
        </section>
        <!-- FOOTER --> 
         <div class="text-center">
                <ul class="pagination">
                  <li><a href="#">1</a></li>
                  <li class="active"><a href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li><a href="#">4</a></li>
                  <li><a href="#">5</a></li>
                </ul>
         </div>
        <!-- END FOOTER --> 
</div><!-- end con fluid -->
@endsection
