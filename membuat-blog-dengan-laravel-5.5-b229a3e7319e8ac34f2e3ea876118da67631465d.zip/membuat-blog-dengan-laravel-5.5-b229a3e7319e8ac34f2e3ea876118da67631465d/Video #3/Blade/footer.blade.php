<footer class="footer">
            <div class="container">
                    <div class="col-sm-4 col-md-offset-4 footer-social text-center">
                        <h3>Social networks</h3>
                        <ul class="footer-nav">
                            <li>
                                <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fa fa-youtube"></i></a>
                            </li>
                        </ul>
                    </div>
            </div>
            <div class="container-fluid footer-p">
                <div class="row">
                    <div class="col-md-12">
                        <p>
                            ©2017 - Teluk Coding
                        </p>
                    </div>
                </div>
            </div>
</footer>
